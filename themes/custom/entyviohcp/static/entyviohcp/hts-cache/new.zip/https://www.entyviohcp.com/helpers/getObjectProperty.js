<!DOCTYPE html>



<html lang="en" data-page-id="Error_404" data-page-category="Orphan" class="no-js" data-isi="overlay">
<head>
    <title>Page Not Found | ENTYVIO (vedolizumab)</title>

    <!-- meta config -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- meta -->
    <meta name="title" content="Page Not Found | ENTYVIO (vedolizumab)">
    <meta name="description" content="">

    <!-- og meta -->
    <meta property="og:site_name" content="ENTYVIO (vedolizumab)" />
    <meta property="og:title" content="Entyvio® (vedolizumab) Official HCP Site " />
    <meta property="og:description" content="The official Entyvio® site for healthcare professionals. See Detailed Important Safety Information and full Prescribing Information." />
    <meta property="og:image" content="https://www.entyviohcp.com/Content/images/logos/Entyvio-logo_OG_image.png" />
    <meta property="og:url" content="https://www.entyviohcp.com/404" />
    <meta property="og:type" content="Article" />
    <meta property="fb:app_id" content="312730800454655" />
    <meta name="facebook-domain-verification" content="wz6o5lhbmua917okvlh37j5coqh7vv" />

    <!-- favicon -->
    <link rel="icon" href="/Content/images/logos/favicon.png" type="image/x-icon" />
    <link rel="shortcut icon" href="/Content/images/logos/favicon.png" type="image/x-icon" />

    <link rel="canonical" href="https://www.entyviohcp.com/404" />

    <script rel="preload" src="/Scripts/dist/main.js?9ACEE82F0D44121C2ABB98FA5832C1193F35EAF57BED54F95179B31DECA5DB1C"></script>
    <script src="/Scripts/src/components/digitalData-Entyvio.js"></script>

        <script src="//assets.adobedtm.com/8fee56b0a165/6889643c630d/launch-bb8830cef805.min.js"></script>
    <!-- Google Tag Manager -->
<script>
    (function (w, d, s, l, i) {
        w[l] = w[l] || []; w[l].push({
            'gtm.start':
                new Date().getTime(), event: 'gtm.js'
        }); var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-M55CCKS');</script>
<!-- End Google Tag Manager -->

    
</head>


<body>

    <div id="layout">
        <a class="skip-navigation" href="#skip-to-content" target="_self">Skip Navigation</a>
        <header data-device="desktop"> <!-- desktop header, mobile navigation -->
	<div>
		<div class="eyebrow">
			<div class="container">
				<nav data-row>
					<ul data-col="mobile-12 desktop-6">
	<li><a href="#isi" target="_self">Important Safety Information</a></li>
	<li><a href="https://general.takedapharm.com/ENTYVIOPI" target="_blank" rel="noreferrer">Prescribing Information</a></li>
	<li><a href="https://general.takedapharm.com/ENTYVIOMG" target="_blank" rel="noreferrer">Medication Guide</a></li>
</ul>

<ul data-col="mobile-12 desktop-6">
	<li><a href="https://www.entyvio.com/" data-modal="external" data-animation="slide" target="_blank" rel="noreferrer">Patient Site</a></li>
	<li class="hcp-site">For U.S. Healthcare Professionals</li>
</ul>
				</nav>
			</div>
		</div>
		<div class="main-nav">
			<div class="container">
				<div class="hcp-text"><p>For U.S. Healthcare Professionals</p></div>
				<div class="logo-container">
					<a class="logo" href="/" target="_self"><img src="/Content/images/logos/logo-entyvio.svg" alt="Entyvio&reg; (vedolizumab) logo." /></a>
					<button data-mobile-menu aria-expanded="false" aria-label="Close Navigation Menu"><span></span></button>
				</div>
				<nav>
					<!-- NAVIGATION STARTS -->
<ul>
    <li class=""><a href="/" title="Home" target="_self">Home</a></li>

    <li class=" has-submenu clinicalefficacy">
        <a href="/clinical-efficacy/ulcerative-colitis/gemini-trial" aria-haspopup="true" aria-expanded="false" target="_self"><span>Clinical <br data-only="desktop" />Efficacy</span></a>
        <button id="mobile_nav_trigger_clinicalefficacy" aria-expanded="false"><span class="visuallyhidden">show submenu for Clinical Efficacy</span></button>
        <div class="subnav clinicalefficacy">
            <div class="uc">
                <h3>UC</h3>
                <ul>
                    <li class=""><a href="/clinical-efficacy/ulcerative-colitis/gemini-trial" target="_self"> GEMINI I: ENTYVIO <em class="vs">vs.</em> PLACEBO</a></li>
                    <li class=""><a href="/clinical-efficacy/ulcerative-colitis/varsity-trial" target="_self">VARSITY: HEAD-TO-HEAD STUDY</a></li>
                </ul>
            </div>

            <div class="cd">
                <h3>CD</h3>
                <ul>
                    <li class=""><a href="/clinical-efficacy/crohns-disease/entyvio-placebo-trial" target="_self">GEMINI II AND III: ENTYVIO <em class="vs">vs.</em> PLACEBO</a></li>
                </ul>
            </div>
        </div>
    </li>

    <li class=""><a href="/mechanism-of-action" target="_self"><span>Mechanism <br data-only="desktop" />of Action</span></a></li>
    <li class=""><a href="/safety-profile" target="_self"><span>Safety <br data-only="desktop" />Profile</span></a></li>
    <li class=""><a href="/dosing-administration" target="_self"><span>Dosing &amp; <br data-only="desktop" />Administration</span></a></li>
    <li class=""><a href="/access-support/insurance-support" target="_self"><span><em data-ec>EntyvioConnect</em></span></a></li>


    
    <li class=" has-submenu resources">
        <a href="/resources/professional-resources" aria-haspopup="true" aria-expanded="false" target="_self"><span>Resources</span></a>
        <button id="mobile_nav_trigger_resources" aria-expanded="false"><span class="visuallyhidden">show submenu for Resources</span></button>
        <div class="subnav resources">
            <div class="">
                <h3 class=""><a href="/resources/professional-resources" target="_self">FOR YOU</a></h3>
                <ul>
                    <li class=""><a href="/resources/virtual-congress" target="_self">ANNUAL CONGRESSES</a></li>
                    <li><a href="https://www.entyviovirtualbooth.com/" data-modal="external" target="_blank">VIRTUAL CONGRESS BOOTH</a></li>
                    <li class=""><a href="/resources/peer-perspective" target="_self">PEER PERSPECTIVES</a></li>
                    <li class=""><a href="/resources/request-a-representative" target="_self">REQUEST A REPRESENTATIVE</a></li>
                    <li class=""><a href="/resources/clinical-reprints" target="_self">CLINICAL REPRINTS</a></li>
                </ul>
            </div>

            <div class="">
                <h3 class=""><a href="/resources/patient-resources" target="_self">FOR YOUR PATIENTS</a></h3>
                <ul>
                    <li class=""><a href="https://locator.infusioncenter.org/" data-modal="external_third_party" target="_blank">INFUSION CENTER LOCATOR</a></li>
                    <li><a href="https://www.entyvio.com/" data-modal="external" target="_blank" rel="noreferrer">ENTYVIO PATIENT SITE</a></li>
                    <li><a href="/local-coverage" target="_self">ENTYVIO COVERAGE FINDER</a></li>
                </ul>
            </div>
        </div>
    </li>
  
</ul>
        <!-- NAVIGATION ENDS -->

				</nav>
			</div>
		</div>
	</div>
</header>

        <div id="content">
            <header data-device="mobile" data-only="mobile"> <!-- Mobile only header; on desktop, this will hide -->
	<div class="for-us-hcp">
		<p>For U.S. Healthcare Professionals</p>
	</div>
	<div>
		<a class="logo" href="/" target="_self"><img src="/Content/images/logos/logo-entyvio.svg" alt="Entyvio&reg; (vedolizumab) logo." /></a>
		<button data-mobile-menu aria-expanded="false" aria-label="Close Navigation Menu"><span></span></button>
	</div>
	<div class="eyebrow">
		<ul>
			<li><a href="#isi" target="_self">Important Safety Information</a></li>
			<li><a href="https://general.takedapharm.com/ENTYVIOPI" target="_blank" rel="noreferrer">Prescribing Information</a></li>
			<li><a href="https://general.takedapharm.com/ENTYVIOMG" target="_blank" rel="noreferrer">Medication Guide</a></li>
			<li><a href="https://www.entyvio.com/" data-modal="external" data-animation="slide" target="_blank" rel="noreferrer">Patient Site</a></li>
		</ul>
	</div>
</header>

            <main id="body">
                <div id="skip-to-content"></div>
                <!-- ************************* -->
                <!-- **** CODE STARTS **** *** -->
                <!-- ************************* -->

                


<div id="hero">
    <div>



                















                            <article>
                <h1>Error 404</h1>
                <h2>Sorry, the page you requested was not found.</h2>
            </article>
            </div>
</div>

<div id="first_section">
    <div id="indication_bar" class="close">
	<div>
		<div class="section">
			<h3>For adult patients with moderately to severely active UC or CD when other therapies have not worked well enough or cannot be&nbsp;tolerated.</h3>
		</div>
	</div>
</div>

    <div>
        <article>
        </article>
    </div>
</div>


                <!-- *********************** -->
                <!-- **** CODE ENDS **** *** -->
                <!-- *********************** -->
            </main>

            <div id="isi">
                <aside class="section">
	<article>
		<button class="fixed_isi_trigger" aria-expanded="false" aria-controls="fixed_isi" aria-label="ISI Expand Button">
            <span></span>
        </button>
        <div class="isi-header">
            <h2>Important Safety Information</h2>
        </div>
		<ul>
			<li>ENTYVIO (vedolizumab) for injection is contraindicated in patients who have had a known serious or severe hypersensitivity reaction to ENTYVIO or any of its excipients.</li>

			<li>Infusion-related reactions and hypersensitivity reactions including anaphylaxis, dyspnea, bronchospasm, urticaria, flushing, rash, and increased blood pressure and heart rate have been reported. These reactions may occur with the first or subsequent infusions and may vary in their time of onset from during infusion or up to several hours post-infusion. If anaphylaxis or other serious infusion-related or hypersensitivity reactions occur, discontinue administration of ENTYVIO immediately and initiate appropriate treatment.</li>

			<li>Patients treated with ENTYVIO are at increased risk for developing infections. Serious infections have been reported in patients treated with ENTYVIO, including anal abscess, sepsis (some fatal), tuberculosis, salmonella sepsis, Listeria meningitis, giardiasis, and cytomegaloviral colitis. ENTYVIO is not recommended in patients with active, severe infections until the infections are controlled. Consider withholding ENTYVIO in patients who develop a severe infection while on treatment with ENTYVIO. Exercise caution in patients with a history of recurring severe infections. Consider screening for tuberculosis (TB) according to the local practice.</li>

			<li>Progressive multifocal leukoencephalopathy (PML), a rare and often fatal opportunistic infection of the central nervous system (CNS), has been reported with systemic immunosuppressants, including another integrin receptor antagonist. PML is caused by the John Cunningham (JC) virus and typically only occurs in patients who are immunocompromised. One case of PML in an ENTYVIO-treated patient with multiple contributory factors has been reported in the postmarketing setting (e.g., human immunodeficiency virus [HIV] infection with a CD4 count of 300 cells/mm<sup>3</sup> and prior and concomitant immunosuppression). Although unlikely, a risk of PML cannot be ruled out. Monitor patients for any new or worsening neurological signs or symptoms. Typical signs and symptoms associated with PML are diverse, progress over days to weeks, and include progressive weakness on one side of the body or clumsiness of limbs, disturbance of vision, and changes in thinking, memory, and orientation leading to confusion and personality changes. If PML is suspected, withhold dosing with ENTYVIO and refer to a neurologist; if confirmed, discontinue ENTYVIO dosing permanently.</li>

			<li>There have been reports of elevations of transaminase and/or bilirubin in patients receiving ENTYVIO. ENTYVIO should be discontinued in patients with jaundice or other evidence of significant liver injury.</li>

			<li>Prior to initiating treatment with ENTYVIO, all patients should be brought up to date with all immunizations according to current immunization guidelines. Patients receiving ENTYVIO may receive non-live vaccines and may receive live vaccines if the benefits outweigh the risks.</li>

			<li>Most common adverse reactions (incidence ≥3% and ≥1% higher than placebo): nasopharyngitis, headache, arthralgia, nausea, pyrexia, upper respiratory tract infection, fatigue, cough, bronchitis, influenza, back pain, rash, pruritus, sinusitis, oropharyngeal pain, and pain in extremities.</li>
		</ul>

		<h2>Indications</h2>
		<h3>Adult Ulcerative Colitis (UC)</h3>
		<p>ENTYVIO (vedolizumab) is indicated in adults for the treatment of moderately to severely active UC.</p>

		<h3>Adult Crohn's Disease (CD)</h3>
		<p>ENTYVIO (vedolizumab) is indicated in adults for the treatment of moderately to severely active CD.</p>

		<p>Please see <a href="https://general.takedapharm.com/ENTYVIOPI" target="_blank" rel="noreferrer">full Prescribing Information</a>, including <a href="https://general.takedapharm.com/ENTYVIOMG" target="_blank" rel="noreferrer">Medication Guide</a>.</p>
	</article>
</aside>

            </div>


            <footer id="footer" data-device="global">
    <div>
        <div class="section">
            <div class="footer-content">
                <a class="takeda-logo" data-modal="external" data-animation="slide" href="http://www.takeda.com/" target="_blank" rel="noreferrer"><img src="/Content/images/logos/logo-takeda.svg" alt="Takeda Pharmaceuticals U.S.A., Inc. logo." /></a>
                <div class="nav-wrapper">
                    <nav>
                        <ul>
                            <li><a data-modal="external" data-animation="slide" href="https://www.takeda.com/en-us/terms-of-use" target="_blank" rel="noreferrer">Terms of Use</a></li>
                            <li><a data-modal="external" data-animation="slide" href="https://www.takeda.com/privacy-notice/" target="_blank" rel="noreferrer">Privacy Notice</a></li>
                            <li><a data-modal="external" data-animation="slide" href="https://www.takeda.com/en-us/who-we-are/contact-us" target="_blank" rel="noreferrer">Contact Us</a></li>
                            <li class=""><a href="/sitemap" target="_self">Site Map</a></li>
                        </ul>
                        <ul>
                            <li><a data-modal="external" data-animation="slide" href="https://www.takedahcp.com/unsubscribe/enrx" target="_blank" rel="noreferrer">Unsubscribe</a></li>
                            <li><a data-modal="external" data-animation="slide" href="https://www.takedahcp.com/" target="_blank" rel="noreferrer">Professional Support</a></li>
                            <li><a data-modal="external_medconnect" data-animation="slide" href="https://www.takedamedconnect.com/" target="_blank" rel="noreferrer">Medical Information</a></li>
                        </ul>
                    </nav>

                    <p>ENTYVIO is a trademark of Millennium Pharmaceuticals, Inc., registered with the U.S. Patent and Trademark Office and is used under license by Takeda Pharmaceuticals America, Inc. All other trademarks are the property of their respective owners.</p>

                    <p>If you are a Colorado prescriber, please see the Colorado WAC <a data-modal="external" href="https://www.takeda.com/siteassets/en-us/home/corporate-responsibility/culture-of-compliance/state/co_entyvio-product-form.pdf" target="_blank" rel="noreferrer">disclosure form</a>.</p>

                    <p>
                        &copy;2021 Takeda&nbsp;Pharmaceuticals U.S.A., Inc.<br />
                        This site is intended for use by U.S. residents only.  
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>
        </div>
    </div>

    <div id="fixed_isi">
        <aside class="section">
	<article>
		<button class="fixed_isi_trigger" aria-expanded="false" aria-controls="fixed_isi" aria-label="ISI Expand Button">
            <span></span>
        </button>
        <div class="isi-header">
            <h2>Important Safety Information</h2>
        </div>
		<ul>
			<li>ENTYVIO (vedolizumab) for injection is contraindicated in patients who have had a known serious or severe hypersensitivity reaction to ENTYVIO or any of its excipients.</li>

			<li>Infusion-related reactions and hypersensitivity reactions including anaphylaxis, dyspnea, bronchospasm, urticaria, flushing, rash, and increased blood pressure and heart rate have been reported. These reactions may occur with the first or subsequent infusions and may vary in their time of onset from during infusion or up to several hours post-infusion. If anaphylaxis or other serious infusion-related or hypersensitivity reactions occur, discontinue administration of ENTYVIO immediately and initiate appropriate treatment.</li>

			<li>Patients treated with ENTYVIO are at increased risk for developing infections. Serious infections have been reported in patients treated with ENTYVIO, including anal abscess, sepsis (some fatal), tuberculosis, salmonella sepsis, Listeria meningitis, giardiasis, and cytomegaloviral colitis. ENTYVIO is not recommended in patients with active, severe infections until the infections are controlled. Consider withholding ENTYVIO in patients who develop a severe infection while on treatment with ENTYVIO. Exercise caution in patients with a history of recurring severe infections. Consider screening for tuberculosis (TB) according to the local practice.</li>

			<li>Progressive multifocal leukoencephalopathy (PML), a rare and often fatal opportunistic infection of the central nervous system (CNS), has been reported with systemic immunosuppressants, including another integrin receptor antagonist. PML is caused by the John Cunningham (JC) virus and typically only occurs in patients who are immunocompromised. One case of PML in an ENTYVIO-treated patient with multiple contributory factors has been reported in the postmarketing setting (e.g., human immunodeficiency virus [HIV] infection with a CD4 count of 300 cells/mm<sup>3</sup> and prior and concomitant immunosuppression). Although unlikely, a risk of PML cannot be ruled out. Monitor patients for any new or worsening neurological signs or symptoms. Typical signs and symptoms associated with PML are diverse, progress over days to weeks, and include progressive weakness on one side of the body or clumsiness of limbs, disturbance of vision, and changes in thinking, memory, and orientation leading to confusion and personality changes. If PML is suspected, withhold dosing with ENTYVIO and refer to a neurologist; if confirmed, discontinue ENTYVIO dosing permanently.</li>

			<li>There have been reports of elevations of transaminase and/or bilirubin in patients receiving ENTYVIO. ENTYVIO should be discontinued in patients with jaundice or other evidence of significant liver injury.</li>

			<li>Prior to initiating treatment with ENTYVIO, all patients should be brought up to date with all immunizations according to current immunization guidelines. Patients receiving ENTYVIO may receive non-live vaccines and may receive live vaccines if the benefits outweigh the risks.</li>

			<li>Most common adverse reactions (incidence ≥3% and ≥1% higher than placebo): nasopharyngitis, headache, arthralgia, nausea, pyrexia, upper respiratory tract infection, fatigue, cough, bronchitis, influenza, back pain, rash, pruritus, sinusitis, oropharyngeal pain, and pain in extremities.</li>
		</ul>

		<h2>Indications</h2>
		<h3>Adult Ulcerative Colitis (UC)</h3>
		<p>ENTYVIO (vedolizumab) is indicated in adults for the treatment of moderately to severely active UC.</p>

		<h3>Adult Crohn's Disease (CD)</h3>
		<p>ENTYVIO (vedolizumab) is indicated in adults for the treatment of moderately to severely active CD.</p>

		<p>Please see <a href="https://general.takedapharm.com/ENTYVIOPI" target="_blank" rel="noreferrer">full Prescribing Information</a>, including <a href="https://general.takedapharm.com/ENTYVIOMG" target="_blank" rel="noreferrer">Medication Guide</a>.</p>
	</article>
</aside>

    </div>
    <!-- MODAL STARTS -->
<div id="modal" role="dialog" aria-modal="true" aria-labelledby="modal_content" data-modal-animation="slide">
	<div id="modal_content">
		<button class="close" aria-label="Close"><span></span></button>

		<section class="content" data-modal-content="external_medconnect">
			<h2>You are about to leave this website.</h2>
			<p>By clicking "Continue," you will leave this site and enter TakedaMedConnect.com. The information contained on Takeda MedConnect is intended for U.S. healthcare professionals only in response to a specific request for medical information.</p>
			<div class="modal-footer">
				<button class="btn btn-secondary close">Cancel</button>
				<a class="btn btn-secondary external" href="" target="_blank" rel="noreferrer">Continue</a>
			</div>
		</section>


		<section class="content" data-modal-content="external">
			<h2>You are about to leave this website.</h2>
			<div class="modal-footer">
				<button class="btn btn-secondary close">Cancel</button>
				<a class="btn btn-secondary external" href="" target="_blank" rel="noreferrer">Continue</a>
			</div>
		</section>


		<section class="content" data-modal-content="external_third_party"> 
			<h2>You are about to leave this website and enter a website operated by an independent third party.</h2>
			<p>The links to third-party websites contained on this website are provided solely for your convenience. Takeda does not control the content contained on any third-party website linked from this website. Your activities at those websites will be governed by the policies and practices of those third parties.</p>

			<p>Please select "Continue" if you wish to be taken to this third-party website.</p>
			<div class="modal-footer">
				<button class="btn btn-secondary close">Cancel</button>
				<a class="btn btn-secondary external" href="" target="_blank" rel="noreferrer">Continue</a>
			</div>
		</section>

	</div>
	<strong></strong>
</div>
<!-- MODAL ENDS -->
    
    <button class="back-to-top btn btn-secondary" tabindex="0">Back to top</button>

    <script>
        const pauseVideo = (id, time) => {
            const video = document.getElementById(id);
            video.pause();
            video.classList.add('playing');
            video.currentTime = time;
        },
            homepage_hover = () => {
                document.querySelector('.head-to-head .btn').classList.add('hover');
                document.querySelector('.btn[href="/mechanism-of-action"]').classList.add('hover');
            },
            Extra_Form_Errors = () => {
                setTimeout(function () {
                    document.querySelectorAll('input, select').forEach(element => element.blur());
                    document.getElementById('Email-error').innerHTML = '<span class="ed-templating">[</span>Please enter your email address.<span class="ed-templating">]</span><br /><span class="ed-templating">[</span>Please enter a valid email address.<span class="ed-templating">]</span>';
                    document.getElementById('Zip-error').innerHTML = '<span class="ed-templating">[</span>Please enter your ZIP code.<span class="ed-templating">]</span><br /><span class="ed-templating">[</span>Please enter a valid ZIP code.<span class="ed-templating">]</span>';
                    document.getElementById('Server-error').innerHTML = 'Sorry, an error occurred while processing your request.';
                }, 1000);
            };
    </script>

    <script type="text/javascript">_satellite.pageBottom();</script>

</body>
</html>